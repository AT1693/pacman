package pacman.tiles;

import java.awt.image.BufferedImage;

import pacman.gfx.Assets;

public class Tile1 extends Tile{

	public Tile1(int id) {
		super(Assets.tile1, id);
		
		
	}

	
}
