package pacman;
public class Launcher {
    public static void main(String args[]){
        Game game=new Game("PACMAN",810,310);
        game.start();
        
        
        
    }
    
}

