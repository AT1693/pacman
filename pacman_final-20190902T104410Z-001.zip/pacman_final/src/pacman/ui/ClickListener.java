package pacman.ui;

public interface ClickListener {
	

	
	public void onClick();
	
	
}
